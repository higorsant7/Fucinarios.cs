﻿namespace Gerenciador_de_setores
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            txtNomeFuncionarios = new TextBox();
            dataGridFuncionarios = new DataGridView();
            conexaoBDBindingSource = new BindingSource(components);
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            groupBox1 = new GroupBox();
            radioButtonMasculino = new RadioButton();
            radioButtonFeminino = new RadioButton();
            label8 = new Label();
            txtId = new TextBox();
            txtNome = new TextBox();
            txtCargo = new TextBox();
            txtSalario = new TextBox();
            maskCPF = new MaskedTextBox();
            dateData = new DateTimePicker();
            cmbSetor = new ComboBox();
            btnCadastrar = new Button();
            btnEditar = new Button();
            btnExcluir = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridFuncionarios).BeginInit();
            ((System.ComponentModel.ISupportInitialize)conexaoBDBindingSource).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(label1, "label1");
            label1.Name = "label1";
            // 
            // txtNomeFuncionarios
            // 
            resources.ApplyResources(txtNomeFuncionarios, "txtNomeFuncionarios");
            txtNomeFuncionarios.BackColor = SystemColors.Window;
            txtNomeFuncionarios.Name = "txtNomeFuncionarios";
            txtNomeFuncionarios.TextChanged += txtNomeFuncionarios_TextChanged;
            // 
            // dataGridFuncionarios
            // 
            resources.ApplyResources(dataGridFuncionarios, "dataGridFuncionarios");
            dataGridFuncionarios.AllowUserToAddRows = false;
            dataGridFuncionarios.AllowUserToDeleteRows = false;
            dataGridFuncionarios.BackgroundColor = SystemColors.Info;
            dataGridFuncionarios.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridFuncionarios.Cursor = Cursors.Cross;
            dataGridFuncionarios.Name = "dataGridFuncionarios";
            dataGridFuncionarios.ReadOnly = true;
            dataGridFuncionarios.CellContentClick += dataGridFuncionarios_CellContentClick;
            dataGridFuncionarios.CellContentDoubleClick += dataGridFuncionarios_CellContentDoubleClick;
            // 
            // conexaoBDBindingSource
            // 
            conexaoBDBindingSource.DataSource = typeof(sistema.conexaoBD);
            // 
            // label2
            // 
            resources.ApplyResources(label2, "label2");
            label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(label3, "label3");
            label3.Name = "label3";
            // 
            // label4
            // 
            resources.ApplyResources(label4, "label4");
            label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(label5, "label5");
            label5.Name = "label5";
            // 
            // label6
            // 
            resources.ApplyResources(label6, "label6");
            label6.Name = "label6";
            // 
            // label7
            // 
            resources.ApplyResources(label7, "label7");
            label7.Name = "label7";
            // 
            // groupBox1
            // 
            resources.ApplyResources(groupBox1, "groupBox1");
            groupBox1.Controls.Add(radioButtonMasculino);
            groupBox1.Controls.Add(radioButtonFeminino);
            groupBox1.Name = "groupBox1";
            groupBox1.TabStop = false;
            // 
            // radioButtonMasculino
            // 
            resources.ApplyResources(radioButtonMasculino, "radioButtonMasculino");
            radioButtonMasculino.Cursor = Cursors.Hand;
            radioButtonMasculino.Name = "radioButtonMasculino";
            radioButtonMasculino.TabStop = true;
            radioButtonMasculino.UseVisualStyleBackColor = true;
            // 
            // radioButtonFeminino
            // 
            resources.ApplyResources(radioButtonFeminino, "radioButtonFeminino");
            radioButtonFeminino.Cursor = Cursors.Hand;
            radioButtonFeminino.Name = "radioButtonFeminino";
            radioButtonFeminino.TabStop = true;
            radioButtonFeminino.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            resources.ApplyResources(label8, "label8");
            label8.Name = "label8";
            // 
            // txtId
            // 
            resources.ApplyResources(txtId, "txtId");
            txtId.Cursor = Cursors.No;
            txtId.Name = "txtId";
            txtId.ReadOnly = true;
            // 
            // txtNome
            // 
            resources.ApplyResources(txtNome, "txtNome");
            txtNome.Name = "txtNome";
            // 
            // txtCargo
            // 
            resources.ApplyResources(txtCargo, "txtCargo");
            txtCargo.Name = "txtCargo";
            // 
            // txtSalario
            // 
            resources.ApplyResources(txtSalario, "txtSalario");
            txtSalario.Name = "txtSalario";
            // 
            // maskCPF
            // 
            resources.ApplyResources(maskCPF, "maskCPF");
            maskCPF.Name = "maskCPF";
            // 
            // dateData
            // 
            resources.ApplyResources(dateData, "dateData");
            dateData.Cursor = Cursors.IBeam;
            dateData.Format = DateTimePickerFormat.Custom;
            dateData.Name = "dateData";
            dateData.Value = new DateTime(2025, 4, 22, 0, 0, 0, 0);
            // 
            // cmbSetor
            // 
            resources.ApplyResources(cmbSetor, "cmbSetor");
            cmbSetor.Cursor = Cursors.Hand;
            cmbSetor.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbSetor.FormattingEnabled = true;
            cmbSetor.Name = "cmbSetor";
            // 
            // btnCadastrar
            // 
            resources.ApplyResources(btnCadastrar, "btnCadastrar");
            btnCadastrar.Cursor = Cursors.Hand;
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.UseVisualStyleBackColor = true;
            btnCadastrar.Click += button1_Click;
            // 
            // btnEditar
            // 
            resources.ApplyResources(btnEditar, "btnEditar");
            btnEditar.BackColor = Color.LightGray;
            btnEditar.Cursor = Cursors.Hand;
            btnEditar.ForeColor = SystemColors.ActiveCaptionText;
            btnEditar.Name = "btnEditar";
            btnEditar.UseVisualStyleBackColor = false;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnExcluir
            // 
            resources.ApplyResources(btnExcluir, "btnExcluir");
            btnExcluir.BackColor = Color.LightGray;
            btnExcluir.Cursor = Cursors.Hand;
            btnExcluir.Name = "btnExcluir";
            btnExcluir.UseVisualStyleBackColor = false;
            btnExcluir.Click += btnExcluir_Click;
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Bisque;
            Controls.Add(btnExcluir);
            Controls.Add(btnEditar);
            Controls.Add(btnCadastrar);
            Controls.Add(cmbSetor);
            Controls.Add(dateData);
            Controls.Add(maskCPF);
            Controls.Add(txtSalario);
            Controls.Add(txtCargo);
            Controls.Add(txtNome);
            Controls.Add(txtId);
            Controls.Add(label8);
            Controls.Add(groupBox1);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(dataGridFuncionarios);
            Controls.Add(txtNomeFuncionarios);
            Controls.Add(label1);
            KeyPreview = true;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            TopMost = true;
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridFuncionarios).EndInit();
            ((System.ComponentModel.ISupportInitialize)conexaoBDBindingSource).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtNomeFuncionarios;
        private DataGridView dataGridFuncionarios;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private GroupBox groupBox1;
        private Label label8;
        private TextBox txtId;
        private TextBox txtNome;
        private TextBox txtCargo;
        private TextBox txtSalario;
        private MaskedTextBox maskCPF;
        private RadioButton radioButtonMasculino;
        private RadioButton radioButtonFeminino;
        private DateTimePicker dateData;
        private ComboBox cmbSetor;
        private Button btnCadastrar;
        private Button btnEditar;
        private Button btnExcluir;
        private BindingSource conexaoBDBindingSource;
    }
}
