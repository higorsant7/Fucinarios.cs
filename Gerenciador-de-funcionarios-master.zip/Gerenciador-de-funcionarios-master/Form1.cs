using System.Data;

namespace Gerenciador_de_setores
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dataGridFuncionarios.AllowUserToAddRows = false;
            caregarSetores();
            Fucionarios funcionarios = new Fucionarios();
            dataGridFuncionarios.DataSource = funcionarios.ListarTodosFucionarios(); // Atualiza o DataGridView para refletir as altera��es

        }
        private void caregarSetores()
        {
            cmbSetor.Items.Clear();
            cmbSetor.Items.Add("RH");
            cmbSetor.Items.Add("TI");
            cmbSetor.Items.Add("Financeiro");
            cmbSetor.Items.Add("Vendas");
        }
        private string VerificarSexo()
        {
            if (radioButtonMasculino.Checked) return "Masculino";
            if (radioButtonFeminino.Checked) return "Feminino";
            return "";
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {

                Fucionarios funcionarios = new Fucionarios();
                DataTable dataTable = funcionarios.ListarTodosFucionarios();

            }
            catch
            {
                MessageBox.Show("Erro ao selecionar funcionario", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (!txtNome.Text.Equals("") && !txtCargo.Text.Equals("") && !txtSalario.Text.Equals(""))
                {
                    Fucionarios funcionarios = new Fucionarios();
                    funcionarios.Nome = txtNome.Text;
                    funcionarios.Cargo = txtCargo.Text;
                    funcionarios.CPF = maskCPF.Text;
                    funcionarios.Salario = Convert.ToDecimal(txtSalario.Text);
                    funcionarios.Setor = cmbSetor.Text;
                    funcionarios.Data_Nacimento = dateData.Value;
                    funcionarios.Sexo = VerificarSexo();

                    funcionarios.inserirFuncionarios();
                    MessageBox.Show("Cadastrado", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtCargo.Clear();
                    txtId.Clear();
                    txtNome.Clear();
                    txtSalario.Clear();
                    maskCPF.Clear();
                    radioButtonFeminino.Checked = false;
                    radioButtonMasculino.Checked = false;
                    dataGridFuncionarios.DataSource = funcionarios.ListarTodosFucionarios(); // Atualiza o DataGridView ap�s a edi��o
                    dataGridFuncionarios.Refresh(); // Atualiza o DataGridView para refletir as altera��es
                    dataGridFuncionarios.ClearSelection();
                    dataGridFuncionarios.AllowUserToAddRows = false;
                    dataGridFuncionarios.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    dataGridFuncionarios.AutoResizeColumns();
                }
                else
                {
                    MessageBox.Show("Preencha todos os campos", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao inserir funcionario: " + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridFuncionarios_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!txtNome.Text.Equals("") && !txtCargo.Text.Equals("") && !txtSalario.Text.Equals(""))
                {
                    Fucionarios fucionarios = new Fucionarios();

                    fucionarios.Id = Convert.ToInt32(txtId.Text);
                    fucionarios.Nome = txtNome.Text;
                    fucionarios.Cargo = txtCargo.Text;
                    fucionarios.CPF = maskCPF.Text;
                    fucionarios.Salario = Convert.ToDecimal(txtSalario.Text);
                    fucionarios.Setor = cmbSetor.Text;
                    fucionarios.Data_Nacimento = dateData.Value;
                    fucionarios.Sexo = VerificarSexo();

                    fucionarios.Atualizarfucionarios();
                    MessageBox.Show("Funcionario atualizado com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCargo.Clear();
                    txtSalario.Clear();
                    txtId.Clear();
                    txtNome.Clear();
                    maskCPF.Clear();
                    radioButtonFeminino.Checked = false;
                    radioButtonMasculino.Checked = false;
                    dataGridFuncionarios.DataSource = fucionarios.ListarTodosFucionarios(); // Atualiza o DataGridView ap�s a edi��o
                    dataGridFuncionarios.Refresh(); // Atualiza o DataGridView para refletir as altera��es
                    dataGridFuncionarios.ClearSelection();
                    dataGridFuncionarios.AllowUserToAddRows = false;
                    dataGridFuncionarios.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    dataGridFuncionarios.AutoResizeColumns();




                }
                else
                {
                    MessageBox.Show("Preencha todos os campos", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao editar funcionario" + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridFuncionarios_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dataGridFuncionarios.Rows[e.RowIndex];

                    txtId.Text = row.Cells["id"]?.Value?.ToString() ?? "";
                    txtNome.Text = row.Cells["nome"]?.Value?.ToString() ?? "";
                    maskCPF.Text = row.Cells["cpf"]?.Value?.ToString() ?? "";

                    // Verifica se a data � v�lida
                    if (DateTime.TryParse(row.Cells["DataNascimento"]?.Value?.ToString(), out DateTime dataNascimento))
                    {
                        dateData.Value = dataNascimento;
                    }

                    txtCargo.Text = row.Cells["cargo"]?.Value?.ToString() ?? "";
                    cmbSetor.Text = row.Cells["setor"]?.Value?.ToString() ?? "";
                    txtSalario.Text = row.Cells["salario"]?.Value?.ToString() ?? "";

                    string sexo = row.Cells["sexo"]?.Value?.ToString() ?? "";
                    radioButtonMasculino.Checked = sexo == "Masculino";
                    radioButtonFeminino.Checked = sexo == "Feminino";
                    dataGridFuncionarios.AllowUserToAddRows = false;
                }
                else
                {
                    MessageBox.Show("Selecione um funcion�rio", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao selecionar funcion�rio:\n" + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private int idFuncionarioSelecionado = 0; // Vari�vel para armazenar o ID do funcion�rio selecionado
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                Fucionarios funcionarios = new Fucionarios();
                if (idFuncionarioSelecionado >= 0)
                {
                    var resutado = MessageBox.Show("Deseja realmente excluir o funcionario?", "Excluir Funcionario", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (resutado == DialogResult.Yes)
                    {
                        //Fucionarios funcionarios = new Fucionarios();
                        funcionarios.Id = Convert.ToInt32(txtId.Text);
                        funcionarios.DeletarFucionarios();
                        MessageBox.Show("Funcion�rio exclu�do com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        txtCargo.Clear();
                        txtSalario.Clear();
                        txtId.Clear();
                        txtNome.Clear();
                        maskCPF.Clear();
                        radioButtonFeminino.Checked = false;
                        radioButtonMasculino.Checked = false;
                        dataGridFuncionarios.DataSource = funcionarios.ListarTodosFucionarios(); // Atualiza o DataGridView ap�s a edi��o
                        dataGridFuncionarios.Refresh(); // Atualiza o DataGridView para refletir as altera��es
                        dataGridFuncionarios.ClearSelection();
                        dataGridFuncionarios.AllowUserToAddRows = false;
                        dataGridFuncionarios.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                        dataGridFuncionarios.AutoResizeColumns();
                    }
                    else
                    {
                        if (resutado == DialogResult.No)
                        {
                            MessageBox.Show("Exclus�o cancelada!", "Aten��o", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtCargo.Clear();
                            txtSalario.Clear();
                            txtId.Clear();
                            txtNome.Clear();
                            maskCPF.Clear();
                            radioButtonFeminino.Checked = false;
                            radioButtonMasculino.Checked = false;
                            dataGridFuncionarios.DataSource = funcionarios.ListarTodosFucionarios(); // Atualiza o DataGridView ap�s a edi��o
                            dataGridFuncionarios.Refresh(); // Atualiza o DataGridView para refletir as altera��es
                            dataGridFuncionarios.ClearSelection();
                            dataGridFuncionarios.AllowUserToAddRows = false;
                            dataGridFuncionarios.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                            dataGridFuncionarios.AutoResizeColumns();

                        }
                    }



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir funcionario: " + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtNomeFuncionarios_TextChanged(object sender, EventArgs e)
        {
            Fucionarios fucionarios = new Fucionarios();
            fucionarios.Nomefuncionario = txtNomeFuncionarios.Text;
            dataGridFuncionarios.DataSource = fucionarios.ListarFucionariospornome(txtNomeFuncionarios.Text);
        }
    }
}
