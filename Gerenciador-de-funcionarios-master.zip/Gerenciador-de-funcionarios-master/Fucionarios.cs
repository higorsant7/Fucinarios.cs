﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using sistema;

namespace Gerenciador_de_setores
{
    class Fucionarios
    {
        private int id;
        private string nome;
        private string cpf;
        private string cargo;
        private string setor;
        private DateTime data_nacimento;
        private decimal salario;
        private string sexo;
        private string nomefuncionario;
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string CPF
        {
            get { return cpf; }
            set { cpf = value; }
        }
        public string Cargo
        {
            get { return cargo; }
            set { cargo = value; }
        }
        public string Setor
        {
            get { return setor; }
            set { setor = value; }
        }
        public DateTime Data_Nacimento
        {
            get { return data_nacimento; }
            set { data_nacimento = value; }
        }
        public decimal Salario
        {
            get { return salario; }
            set { salario = value; }
        }
        public string Sexo
        {
            get { return sexo; }
            set { sexo = value; }
        }
        public string Nomefuncionario
        {
            get { return nomefuncionario; }
            set { nomefuncionario = value; }
        }


        public bool inserirFuncionarios()
        {
            try
            {
                using (MySqlConnection conexao = new conexaoBD().Conectar())
                {
                    string sql = "INSERT INTO usuarioFunc (Nome, CPF, DataNascimento, Cargo, Setor, Salario, Sexo) VALUES (@Nome, @CPF, @DataNascimento ,@Cargo, @Setor, @Salario, @Sexo)";
                    MySqlCommand cmd = new MySqlCommand(sql, conexao);
                    DateTime data_nacimentoMysql = Convert.ToDateTime(Data_Nacimento); // coverte a data para o formato de texto 
                    string dataNacimentoFormatada = data_nacimentoMysql.ToString("yyyy-MM-dd"); // formata a data para o formato correto
                    cmd.Parameters.AddWithValue("@Nome", Nome);
                    cmd.Parameters.AddWithValue("@CPF", CPF);
                    cmd.Parameters.AddWithValue("@DataNascimento", dataNacimentoFormatada);
                    cmd.Parameters.AddWithValue("@Cargo", Cargo);
                    cmd.Parameters.AddWithValue("@Setor", Setor);
                    cmd.Parameters.AddWithValue("@Salario", Salario);
                    cmd.Parameters.AddWithValue("@Sexo", Sexo);

                    int resultado = cmd.ExecuteNonQuery();

                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;   
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Erro ao inserir funcionário: " + ex.Message);
                return false;
            }
        }
        public void Atualizarfucionarios()
        {
            using (MySqlConnection conexao = new conexaoBD().Conectar())
            {
                try
                {
                    string sql = "UPDATE usuarioFunc SET Nome = @Nome, CPF = @CPF, DataNascimento = @DataNascimento, Cargo = @Cargo, Setor = @Setor, Salario = @Salario, Sexo = @Sexo WHERE id = @id";

                    MySqlCommand cmd = new MySqlCommand(sql, conexao);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@Nome", nome);
                    cmd.Parameters.AddWithValue("@CPF", CPF);

                    // Converte e formata a data para o MySQL
                    DateTime data_nascimentoMysql = Convert.ToDateTime(data_nacimento);
                    string dataFormatada = data_nascimentoMysql.ToString("yyyy-MM-dd");
                    cmd.Parameters.AddWithValue("@DataNascimento", dataFormatada); // Corrigido nome do parâmetro

                    cmd.Parameters.AddWithValue("@Cargo", cargo);
                    cmd.Parameters.AddWithValue("@Setor", setor);
                    cmd.Parameters.AddWithValue("@Salario", salario);
                    cmd.Parameters.AddWithValue("@Sexo", sexo);

                    cmd.ExecuteNonQuery();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro ao atualizar funcionário: " + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public void DeletarFucionarios()
        {
            using (MySqlConnection conexao = new conexaoBD().Conectar())
                try
                {
                    string sql = "DELETE FROM funcionariosBD.usuarioFunc WHERE id = @id";
                    MySqlCommand cmd = new MySqlCommand(sql, conexao);
                    cmd.Parameters.AddWithValue("@id", Id);
                    cmd.ExecuteNonQuery();
                }
                catch (MySqlException ex)
                {
                    Console.WriteLine("Erro ao deletar funcionário: " + ex.Message);
                }
        }
        public DataTable ListarTodosFucionarios()
        {
            DataTable dt = new DataTable();
            using (MySqlConnection conexao = new conexaoBD().Conectar())
                try
                {
                    string sql = "SELECT * FROM usuarioFunc";
                    MySqlCommand cmd = new MySqlCommand(sql, conexao);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(dt);
                }
                catch (MySqlException ex)
                {
                    Console.WriteLine("Erro ao listar funcionários: " + ex.Message);
                }
            return dt;
        }
        public DataTable ListarFucionariospornome(string nome)
        {
            DataTable dt = new DataTable();
            using (MySqlConnection conexao = new conexaoBD().Conectar())
                try
                {
                    string sql = "SELECT * FROM funcionariosBD.usuarioFunc WHERE Nome LIKE @Nome";
                    MySqlCommand cmd = new MySqlCommand(sql, conexao);
                    cmd.Parameters.AddWithValue("@Nome", "%" + Nomefuncionario + "%");
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(dt);

                    
                }
                catch (MySqlException ex)
                {
                    Console.WriteLine("Erro ao listar funcionários: " + ex.Message);
                }
            return dt;
        }
    }
}
